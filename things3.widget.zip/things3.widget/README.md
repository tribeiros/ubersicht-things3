# Things 3 widget
Show your today things on desktop

![Screenshot](https://github.com/tribeiros/ubersicht-things3/blob/main/screenshot.png)

## reqs
sqlite cli 
`brew install sqlite3`

Change `index.coffe` with your username on __path__ at **sqliteDb** variable

Things 3 :)


